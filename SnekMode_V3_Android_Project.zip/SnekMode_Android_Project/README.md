# SnekMode – Python Glow Up Android App

This is a ready-to-open Android Studio project wrapping the full SnekMode Python course as a native Android application shell.

## Build APK
1. Install/open Android Studio.
2. Choose **Open** and select this `SnekMode_Android_Project` folder.
3. Let Gradle sync and install any requested Android SDK components.
4. Select **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on your Android phone.

The launcher app is `SnekMode – Python Glow Up`.

## V3 additions
- iOS-style dark login screen (local account or guest; stored on-device only)
- Animated "Made by Veekshith" watermark in the corner
- Sign out button in Settings
- Auto-advance to the next lesson after "Got it" or a correct coding answer
- Cleaner login layout, smoother animations, safe-area fixes for Android 15 (status bar / keyboard)

## Important
The course itself is bundled in `app/src/main/assets/index.html`.
The interactive Python runner uses Pyodide from jsDelivr, so coding execution needs internet access unless Pyodide is later bundled locally.
